import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, BookOpen, Calendar, TrendingUp } from 'lucide-react';

const Dashboard = () => {
  const [stats, setStats] = useState({
    totalStudents: 0,
    totalCourses: 0,
    todayAttendance: 0,
    averageAttendance: 0,
  });

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    const { data: students } = await supabase.from('students').select('*', { count: 'exact' });
    const { data: courses } = await supabase.from('courses').select('*', { count: 'exact' });
    const { data: todaySessions } = await supabase
      .from('attendance_sessions')
      .select('*', { count: 'exact' })
      .eq('attendance_date', new Date().toISOString().split('T')[0]);

    setStats({
      totalStudents: students?.length || 0,
      totalCourses: courses?.length || 0,
      todayAttendance: todaySessions?.length || 0,
      averageAttendance: 85,
    });
  };

  const statCards = [
    { title: 'Total Students', value: stats.totalStudents, icon: Users, color: 'text-blue-600' },
    { title: 'Total Courses', value: stats.totalCourses, icon: BookOpen, color: 'text-green-600' },
    { title: 'Today\'s Sessions', value: stats.todayAttendance, icon: Calendar, color: 'text-orange-600' },
    { title: 'Avg. Attendance', value: `${stats.averageAttendance}%`, icon: TrendingUp, color: 'text-purple-600' },
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Dashboard</h1>
        <p className="text-muted-foreground">Welcome to Student Management System</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <stat.icon className={`h-5 w-5 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">• Add new students</p>
              <p className="text-sm text-muted-foreground">• Create courses</p>
              <p className="text-sm text-muted-foreground">• Mark attendance</p>
              <p className="text-sm text-muted-foreground">• Record marks</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">No recent activity</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
