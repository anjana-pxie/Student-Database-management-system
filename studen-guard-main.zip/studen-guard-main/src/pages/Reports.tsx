import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface Student {
  student_id: string;
  roll_no: string;
  first_name: string;
  last_name: string | null;
}

interface Course {
  course_id: string;
  course_code: string;
  course_name: string;
}

interface AttendanceReport {
  total_sessions: number;
  present_count: number;
  absent_count: number;
  late_count: number;
  percentage: number;
}

const Reports = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [selectedStudent, setSelectedStudent] = useState('');
  const [selectedCourse, setSelectedCourse] = useState('');
  const [attendanceReport, setAttendanceReport] = useState<AttendanceReport | null>(null);
  const [marksData, setMarksData] = useState<any[]>([]);

  useEffect(() => {
    fetchStudents();
    fetchCourses();
  }, []);

  useEffect(() => {
    if (selectedStudent && selectedCourse) {
      fetchAttendanceReport();
      fetchMarksReport();
    }
  }, [selectedStudent, selectedCourse]);

  const fetchStudents = async () => {
    const { data } = await supabase.from('students').select('*').eq('status', 'Active').order('roll_no');
    if (data) setStudents(data);
  };

  const fetchCourses = async () => {
    const { data } = await supabase.from('courses').select('*').order('course_code');
    if (data) setCourses(data);
  };

  const fetchAttendanceReport = async () => {
    const { data: sessions } = await supabase
      .from('attendance_sessions')
      .select('session_id')
      .eq('course_id', selectedCourse);

    if (!sessions || sessions.length === 0) {
      setAttendanceReport({
        total_sessions: 0,
        present_count: 0,
        absent_count: 0,
        late_count: 0,
        percentage: 0,
      });
      return;
    }

    const sessionIds = sessions.map((s) => s.session_id);

    const { data: records } = await supabase
      .from('attendance_records')
      .select('status')
      .eq('student_id', selectedStudent)
      .in('session_id', sessionIds);

    if (records) {
      const present = records.filter((r) => r.status === 'Present').length;
      const absent = records.filter((r) => r.status === 'Absent').length;
      const late = records.filter((r) => r.status === 'Late').length;
      const total = records.length;

      setAttendanceReport({
        total_sessions: total,
        present_count: present,
        absent_count: absent,
        late_count: late,
        percentage: total > 0 ? (present / total) * 100 : 0,
      });
    }
  };

  const fetchMarksReport = async () => {
    const { data } = await supabase
      .from('marks')
      .select('*')
      .eq('student_id', selectedStudent)
      .eq('course_id', selectedCourse)
      .order('exam_date', { ascending: false });

    if (data) setMarksData(data);
  };

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Reports</h1>
        <p className="text-muted-foreground">View student performance and attendance reports</p>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="space-y-2">
          <Label>Select Student</Label>
          <Select value={selectedStudent} onValueChange={setSelectedStudent}>
            <SelectTrigger>
              <SelectValue placeholder="Choose a student" />
            </SelectTrigger>
            <SelectContent>
              {students.map((student) => (
                <SelectItem key={student.student_id} value={student.student_id}>
                  {student.roll_no} - {student.first_name} {student.last_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>Select Course</Label>
          <Select value={selectedCourse} onValueChange={setSelectedCourse}>
            <SelectTrigger>
              <SelectValue placeholder="Choose a course" />
            </SelectTrigger>
            <SelectContent>
              {courses.map((course) => (
                <SelectItem key={course.course_id} value={course.course_id}>
                  {course.course_code} - {course.course_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {selectedStudent && selectedCourse && attendanceReport && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Total Sessions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{attendanceReport.total_sessions}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Present
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {attendanceReport.present_count}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Absent
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">
                  {attendanceReport.absent_count}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Attendance %
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {attendanceReport.percentage.toFixed(2)}%
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Examination Marks</CardTitle>
            </CardHeader>
            <CardContent>
              {marksData.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Exam Type</TableHead>
                      <TableHead>Marks Obtained</TableHead>
                      <TableHead>Total Marks</TableHead>
                      <TableHead>Percentage</TableHead>
                      <TableHead>Exam Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {marksData.map((mark) => (
                      <TableRow key={mark.mark_id}>
                        <TableCell className="font-medium">{mark.exam_type}</TableCell>
                        <TableCell>{mark.marks_obtained}</TableCell>
                        <TableCell>{mark.total_marks}</TableCell>
                        <TableCell>
                          {((mark.marks_obtained / mark.total_marks) * 100).toFixed(2)}%
                        </TableCell>
                        <TableCell>{mark.exam_date || 'N/A'}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <p className="text-muted-foreground">No marks recorded yet</p>
              )}
            </CardContent>
          </Card>
        </>
      )}

      {(!selectedStudent || !selectedCourse) && (
        <Card>
          <CardContent className="py-12">
            <p className="text-center text-muted-foreground">
              Select a student and course to view reports
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default Reports;
