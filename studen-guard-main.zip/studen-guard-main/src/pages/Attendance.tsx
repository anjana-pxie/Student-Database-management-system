import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Calendar, Plus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Course {
  course_id: string;
  course_code: string;
  course_name: string;
}

interface Student {
  student_id: string;
  roll_no: string;
  first_name: string;
  last_name: string | null;
}

interface AttendanceRecord {
  student_id: string;
  status: 'Present' | 'Absent' | 'Late';
}

const Attendance = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);

  const [formData, setFormData] = useState({
    course_id: '',
    attendance_date: new Date().toISOString().split('T')[0],
    lecture_no: 1,
  });

  useEffect(() => {
    fetchCourses();
  }, []);

  const fetchCourses = async () => {
    const { data, error } = await supabase.from('courses').select('*').order('course_name');
    if (!error && data) setCourses(data);
  };

  const fetchEnrolledStudents = async (courseId: string) => {
    const { data, error } = await supabase
      .from('enrollments')
      .select('student_id, students(student_id, roll_no, first_name, last_name)')
      .eq('course_id', courseId);

    if (!error && data) {
      const studentsList = data
        .map((e: any) => e.students)
        .filter(Boolean) as Student[];
      setStudents(studentsList);
      setAttendance(
        studentsList.map((s) => ({
          student_id: s.student_id,
          status: 'Present' as const,
        }))
      );
    }
  };

  const handleCourseChange = (courseId: string) => {
    setFormData({ ...formData, course_id: courseId });
    fetchEnrolledStudents(courseId);
  };

  const updateAttendance = (studentId: string, status: 'Present' | 'Absent' | 'Late') => {
    setAttendance((prev) =>
      prev.map((a) => (a.student_id === studentId ? { ...a, status } : a))
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.course_id) {
      toast({ title: 'Error', description: 'Please select a course', variant: 'destructive' });
      return;
    }

    const { data: existingSession } = await supabase
      .from('attendance_sessions')
      .select('session_id')
      .eq('course_id', formData.course_id)
      .eq('attendance_date', formData.attendance_date)
      .eq('lecture_no', formData.lecture_no)
      .maybeSingle();

    if (existingSession) {
      toast({
        title: 'Error',
        description: 'Attendance for this session already exists',
        variant: 'destructive',
      });
      return;
    }

    const { data: session, error: sessionError } = await supabase
      .from('attendance_sessions')
      .insert([
        {
          course_id: formData.course_id,
          attendance_date: formData.attendance_date,
          lecture_no: formData.lecture_no,
        },
      ])
      .select()
      .single();

    if (sessionError) {
      toast({ title: 'Error', description: sessionError.message, variant: 'destructive' });
      return;
    }

    const records = attendance.map((a) => ({
      session_id: session.session_id,
      student_id: a.student_id,
      status: a.status,
    }));

    const { error: recordsError } = await supabase.from('attendance_records').insert(records);

    if (recordsError) {
      toast({ title: 'Error', description: recordsError.message, variant: 'destructive' });
    } else {
      toast({ title: 'Success', description: 'Attendance marked successfully' });
      resetForm();
    }
  };

  const resetForm = () => {
    setFormData({
      course_id: '',
      attendance_date: new Date().toISOString().split('T')[0],
      lecture_no: 1,
    });
    setStudents([]);
    setAttendance([]);
    setOpen(false);
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">Attendance</h1>
          <p className="text-muted-foreground">Mark and track student attendance</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Mark Attendance
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Mark Attendance</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="course">Course *</Label>
                  <Select value={formData.course_id} onValueChange={handleCourseChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select course" />
                    </SelectTrigger>
                    <SelectContent>
                      {courses.map((course) => (
                        <SelectItem key={course.course_id} value={course.course_id}>
                          {course.course_code} - {course.course_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="date">Date *</Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.attendance_date}
                    onChange={(e) => setFormData({ ...formData, attendance_date: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lecture">Lecture No</Label>
                  <Input
                    id="lecture"
                    type="number"
                    min="1"
                    value={formData.lecture_no}
                    onChange={(e) =>
                      setFormData({ ...formData, lecture_no: parseInt(e.target.value) })
                    }
                  />
                </div>
              </div>

              {students.length > 0 && (
                <>
                  <div className="border rounded-lg">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Roll No</TableHead>
                          <TableHead>Student Name</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {students.map((student) => {
                          const record = attendance.find((a) => a.student_id === student.student_id);
                          return (
                            <TableRow key={student.student_id}>
                              <TableCell className="font-medium">{student.roll_no}</TableCell>
                              <TableCell>
                                {student.first_name} {student.last_name}
                              </TableCell>
                              <TableCell>
                                <Select
                                  value={record?.status}
                                  onValueChange={(value: 'Present' | 'Absent' | 'Late') =>
                                    updateAttendance(student.student_id, value)
                                  }
                                >
                                  <SelectTrigger className="w-32">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="Present">Present</SelectItem>
                                    <SelectItem value="Absent">Absent</SelectItem>
                                    <SelectItem value="Late">Late</SelectItem>
                                  </SelectContent>
                                </Select>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button type="button" variant="outline" onClick={resetForm}>
                      Cancel
                    </Button>
                    <Button type="submit">Submit Attendance</Button>
                  </div>
                </>
              )}
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="border rounded-lg p-8 text-center">
        <Calendar className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
        <h3 className="text-xl font-semibold mb-2">Attendance Tracking</h3>
        <p className="text-muted-foreground mb-4">
          Click "Mark Attendance" to record attendance for a class session
        </p>
      </div>
    </div>
  );
};

export default Attendance;
