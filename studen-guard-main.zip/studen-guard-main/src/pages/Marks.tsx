import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Mark {
  mark_id: string;
  student_id: string;
  course_id: string;
  exam_type: string;
  marks_obtained: number;
  total_marks: number;
  exam_date: string | null;
  remarks: string | null;
  students: {
    roll_no: string;
    first_name: string;
    last_name: string | null;
  };
  courses: {
    course_code: string;
    course_name: string;
  };
}

interface Student {
  student_id: string;
  roll_no: string;
  first_name: string;
  last_name: string | null;
}

interface Course {
  course_id: string;
  course_code: string;
  course_name: string;
}

const Marks = () => {
  const [marks, setMarks] = useState<Mark[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [open, setOpen] = useState(false);
  const [editingMark, setEditingMark] = useState<Mark | null>(null);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    student_id: '',
    course_id: '',
    exam_type: '',
    marks_obtained: 0,
    total_marks: 100,
    exam_date: '',
    remarks: '',
  });

  useEffect(() => {
    fetchMarks();
    fetchStudents();
    fetchCourses();
  }, []);

  const fetchMarks = async () => {
    const { data, error } = await supabase
      .from('marks')
      .select(`
        *,
        students(roll_no, first_name, last_name),
        courses(course_code, course_name)
      `)
      .order('exam_date', { ascending: false });

    if (error) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } else {
      setMarks(data as any || []);
    }
  };

  const fetchStudents = async () => {
    const { data } = await supabase.from('students').select('*').eq('status', 'Active').order('roll_no');
    if (data) setStudents(data);
  };

  const fetchCourses = async () => {
    const { data } = await supabase.from('courses').select('*').order('course_code');
    if (data) setCourses(data);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (editingMark) {
      const { error } = await supabase
        .from('marks')
        .update(formData)
        .eq('mark_id', editingMark.mark_id);

      if (error) {
        toast({ title: 'Error', description: error.message, variant: 'destructive' });
      } else {
        toast({ title: 'Success', description: 'Marks updated successfully' });
        fetchMarks();
        resetForm();
      }
    } else {
      const { error } = await supabase.from('marks').insert([formData]);

      if (error) {
        toast({ title: 'Error', description: error.message, variant: 'destructive' });
      } else {
        toast({ title: 'Success', description: 'Marks added successfully' });
        fetchMarks();
        resetForm();
      }
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this record?')) return;

    const { error } = await supabase.from('marks').delete().eq('mark_id', id);

    if (error) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Success', description: 'Record deleted successfully' });
      fetchMarks();
    }
  };

  const resetForm = () => {
    setFormData({
      student_id: '',
      course_id: '',
      exam_type: '',
      marks_obtained: 0,
      total_marks: 100,
      exam_date: '',
      remarks: '',
    });
    setEditingMark(null);
    setOpen(false);
  };

  const handleEdit = (mark: Mark) => {
    setEditingMark(mark);
    setFormData({
      student_id: mark.student_id,
      course_id: mark.course_id,
      exam_type: mark.exam_type,
      marks_obtained: mark.marks_obtained,
      total_marks: mark.total_marks,
      exam_date: mark.exam_date || '',
      remarks: mark.remarks || '',
    });
    setOpen(true);
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">Marks</h1>
          <p className="text-muted-foreground">Manage student examination marks</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingMark(null)}>
              <Plus className="mr-2 h-4 w-4" />
              Add Marks
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>{editingMark ? 'Edit Marks' : 'Add New Marks'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="student">Student *</Label>
                <Select value={formData.student_id} onValueChange={(value) => setFormData({ ...formData, student_id: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select student" />
                  </SelectTrigger>
                  <SelectContent>
                    {students.map((student) => (
                      <SelectItem key={student.student_id} value={student.student_id}>
                        {student.roll_no} - {student.first_name} {student.last_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="course">Course *</Label>
                <Select value={formData.course_id} onValueChange={(value) => setFormData({ ...formData, course_id: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select course" />
                  </SelectTrigger>
                  <SelectContent>
                    {courses.map((course) => (
                      <SelectItem key={course.course_id} value={course.course_id}>
                        {course.course_code} - {course.course_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="exam_type">Exam Type *</Label>
                <Input
                  id="exam_type"
                  placeholder="e.g., Midterm, Final, Quiz"
                  value={formData.exam_type}
                  onChange={(e) => setFormData({ ...formData, exam_type: e.target.value })}
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="marks_obtained">Marks Obtained *</Label>
                  <Input
                    id="marks_obtained"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.marks_obtained}
                    onChange={(e) => setFormData({ ...formData, marks_obtained: parseFloat(e.target.value) })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="total_marks">Total Marks *</Label>
                  <Input
                    id="total_marks"
                    type="number"
                    min="1"
                    step="0.01"
                    value={formData.total_marks}
                    onChange={(e) => setFormData({ ...formData, total_marks: parseFloat(e.target.value) })}
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="exam_date">Exam Date</Label>
                <Input
                  id="exam_date"
                  type="date"
                  value={formData.exam_date}
                  onChange={(e) => setFormData({ ...formData, exam_date: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="remarks">Remarks</Label>
                <Input
                  id="remarks"
                  value={formData.remarks}
                  onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
                <Button type="submit">{editingMark ? 'Update' : 'Add'} Marks</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="border rounded-lg">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Roll No</TableHead>
              <TableHead>Student Name</TableHead>
              <TableHead>Course</TableHead>
              <TableHead>Exam Type</TableHead>
              <TableHead>Marks</TableHead>
              <TableHead>Percentage</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {marks.map((mark) => (
              <TableRow key={mark.mark_id}>
                <TableCell className="font-medium">{mark.students.roll_no}</TableCell>
                <TableCell>
                  {mark.students.first_name} {mark.students.last_name}
                </TableCell>
                <TableCell>
                  {mark.courses.course_code}
                </TableCell>
                <TableCell>{mark.exam_type}</TableCell>
                <TableCell>
                  {mark.marks_obtained}/{mark.total_marks}
                </TableCell>
                <TableCell>
                  {((mark.marks_obtained / mark.total_marks) * 100).toFixed(2)}%
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm" onClick={() => handleEdit(mark)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(mark.mark_id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default Marks;
